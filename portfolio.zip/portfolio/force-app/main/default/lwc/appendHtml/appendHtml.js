import { api, LightningElement } from 'lwc';

export default class AppendHtml extends LightningElement {


    _result;
    show = false;

    @api
    get result(){
        return this._result;
    }

    set result(data)
    {
        this._result = data;
        if(this.show){
            this.appendHtml();
        }
    }

    renderedCallback(){
        if(this._result && !this.show)
        {
            this.appendHtml();
        }
    }
    appendHtml()
    {
        const element = this.template.querySelector('.htmlContainer')
        if(element) {
            element.innerHTML = this.result;
            this.show = true;
        }
    }
}