import { api, LightningElement,wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import SOFT_SKILLS from '@salesforce/schema/Portfolio__c.SoftSkills__c';
import SOFTWARE_TOOLS from '@salesforce/schema/Portfolio__c.SoftwareTools__c'
import TECH_SKILLS from '@salesforce/schema/Portfolio__c.TechnicalSkills__c'
import METHODOLOGY from '@salesforce/schema/Portfolio__c.Methodology__c'
export default class PortfolioSkills extends LightningElement {

    @api recordId;

    softSkills=[];
    softwareTools=[];
    technicalSkills=[];
    methodology=[];


    @wire(getRecord, { recordId: '$recordId', fields: [SOFT_SKILLS, SOFTWARE_TOOLS, TECH_SKILLS, METHODOLOGY] })
    portfolioRecorddetails({error,data}){
        if(data)
        {
            console.log('prtfdata'+JSON.stringify(data));
            this.formatData(data);
        }
        if(error){
            console.error('error'+error);
        }
    }


    formatData(data){

        const {SoftSkills__c,SoftwareTools__c,TechnicalSkills__c,Methodology__c} =data.fields;
        this.softSkills= SoftSkills__c ? SoftSkills__c.value.split(','):[];
        this.softwareTools= SoftwareTools__c? SoftwareTools__c.value.split(','):[];
        this.technicalSkills= TechnicalSkills__c? TechnicalSkills__c.value.split(','):[];
        this.methodology= Methodology__c? Methodology__c.value.split(','):[];
    }

}