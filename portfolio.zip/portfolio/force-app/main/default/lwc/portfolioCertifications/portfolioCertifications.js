import { api, LightningElement, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import SalesforceCertifications from '@salesforce/schema/Portfolio__c.SalesforceCertifications__c';
import OtherCertifications from '@salesforce/schema/Portfolio__c.Other_certifications__c';
import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets';
export default class PortfolioCertifications extends LightningElement {

    @api recordId;
    certLogo = `${PortfolioAssets}/PortfolioAssets/cert_logo.png`;
    sfcert=[];
    othercert=[];
    @wire(getRecord,{
        recordId: '$recordId',
        fields: [SalesforceCertifications,OtherCertifications]
    })
    cartifiactionsData({data,error}){
        if(data){
            //console.log(JSON.stringify(data));
            this.formatData(data);
        }
        if(error){
            console.error('Error fetching record data: ', JSON.stringify(error));
        }
    }
    formatData(data){
        

            const{SalesforceCertifications__c,Other_certifications__c} = data.fields;
              this.sfcert = SalesforceCertifications__c?SalesforceCertifications__c.value.split(';').map((item) =>
                {
                    return `Salesforce certified ${item}`;
                }):[];

               this.othercert = Other_certifications__c?Other_certifications__c.value.split(','):[];
               console.log('formatted data sf',JSON.stringify(this.sfcert));
               console.log('formatted data other',JSON.stringify(this.othercert));    

            }


}