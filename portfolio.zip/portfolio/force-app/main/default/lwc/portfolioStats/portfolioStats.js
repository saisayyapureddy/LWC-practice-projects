import { LightningElement,api } from 'lwc';
import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets';
export default class PortfolioStats extends LightningElement {
    
   @api badges
   @api points
   @api trails
   @api trailheadRank

   // Getter to dynamically compute the image URL based on trailheadRank
   get trailheadRankimage() {
    return `${PortfolioAssets}/PortfolioAssets/Ranks/${this.trailheadRank}.png`;
 }

//  connectedCallback() {
//    console.log(this.trailheadRank, 'in connected callback');
//  }


//  renderedCallback() {
//     console.log('Rendered with trailheadRank:', this.trailheadRank);
//     console.log('Image URL:', this.trailheadRankimage);
//  }
 
}