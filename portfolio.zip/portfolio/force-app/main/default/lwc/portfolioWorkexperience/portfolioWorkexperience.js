import { api, LightningElement, wire } from 'lwc';
import { getRelatedListRecords } from 'lightning/uiRelatedListApi';

export default class PortfolioWorkexperience extends LightningElement {
    @api recordId; // Ensure this is correctly annotated with @api

    workExperienceList=[];

    //getting related records
    @wire(getRelatedListRecords, {
        parentRecordId: '$recordId',
        relatedListId: 'Work_Experiences__r',
        fields: ['Work_Experience__c.Company_Name__c', 'Work_Experience__c.Role__c', 'Work_Experience__c.Description__c', 'Work_Experience__c.Is_current__c',
             'Work_Experience__c.Job_start_date__c', 'Work_Experience__c.Job_end_date__c', 'Work_Experience__c.Company_location__c']
    })
    wiredWorkExperience({ error, data }) {
        if (data) {
            console.log('experience data', JSON.stringify(data));
            this.formatData(data);
        } else if (error) {
            console.error('Error in getting work experience records: ', error);
        }
    }
    formatData(data){
        this.workExperienceList = data.records.map((item) => {
            let id = item.id;
            const{Company_Name__c, Role__c, Description__c,Is_current__c,Job_start_date__c,Job_end_date__c,Company_location__c} = item.fields
            let companyName = this.getData(Company_Name__c);
            let role = this.getData(Role__c); 
            let description = this.getData(Description__c);
            let isCurrent = this.getData(Is_current__c);
            let startDate = this.getData(Job_start_date__c);
            let endDate = this.getData(Job_end_date__c);
            let location = this.getData(Company_location__c);
            return { id, companyName, role, description, isCurrent, startDate, endDate, location }

        })
        console.log('formatted data', JSON.stringify(this.workExperienceList));
    }

    getData(data)
    {
        return data && (data.displayValue || data.value)
    }

    // extractTextFromHtml(htmlString) {
    //     const div = document.createElement('div');
    //     div.innerHTML = htmlString;
    //     return div.textContent || div.innerText || "";
    // }


}
