import { LightningElement, wire } from 'lwc';

import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import CATEGORY from '@salesforce/schema/Cars__c.Category__c';
import MAKE from '@salesforce/schema/Cars__c.Make__c';
import CAR from '@salesforce/schema/Cars__c';



//LMS message channel
import { publish,MessageContext } from 'lightning/messageService';
import CAR_FILTERED_MESSAGE from '@salesforce/messageChannel/CarsFiltered__c';

const CATEGORY_ERROR = "No category Found";
const MAKE_ERROR = "No Make Found";
export default class Car_filter extends LightningElement {

    timer;
    filters={
        searchKey:'',
        maxPrice:999999
    }


    categoryError = CATEGORY_ERROR;
    makeError = MAKE_ERROR;

    @wire(MessageContext)
    messageContext;



    @wire(getObjectInfo,{
        objectApiName: CAR
    })
    carObjectInfo;


    @wire(getPicklistValues, {
        recordTypeId: '$carObjectInfo.data.defaultRecordTypeId',
        fieldApiName: CATEGORY
    })
    category;

    @wire(getPicklistValues, {
        recordTypeId: '$carObjectInfo.data.defaultRecordTypeId',
        fieldApiName: MAKE
    })
    make;


    handleSearchKeyChange(event)
    {

        this.filters = {...this.filters,"searchKey":event.target.value}
        //console.log(this.filters);
        this.sendDataToCarList();
    }


    handleMaxPriceChange(event)
    {
        this.filters = {...this.filters,"maxPrice":event.target.value};
        //console.log(this.filters);
        this.sendDataToCarList();
    }

    handleCheckbox(event)
    {
        // This checks if the categories property in the filters object is not already set.
        if(!this.filters.categories)
        {
            const categories = this.category.data.values.map((item) => item.value);
            const makeType  = this.make.data.values.map((item) => item.value);
            this.filters = {...this.filters, categories, makeType};
        }
        const {name,value} = event.target.dataset;

        //Updating the filters Object Based on Checkbox State
        /*
            If the checkbox is checked (event.target.checked is true):
            The method checks if the selected value is not already in the corresponding array of filters[name] (either categories or makeType).
            If it's not present, it adds the value to the array using the spread operator (...).

        */
       // console.log(JSON.stringify(this.filters));
        if(event.target.checked)
        {
                if(!this.filters[name].includes(value))
                {
                    //console.log(JSON.stringify(this.filters));
                    this.filters[name] = [... this.filters[name], value];
                    //console.log(JSON.stringify(this.filters));
                }
                
        }
        else{
            //If the checkbox is unchecked (event.target.checked is false):
            //The method checks if the selected value is present in the corresponding array of filters[name].
            //If it is present, it removes the value using the filter method.
            //console.log(JSON.stringify(this.filters));
            this.filters[name] = this.filters[name].filter((item) => item!== value);
           // console.log(JSON.stringify(this.filters));
        }
        this.sendDataToCarList();
        
    }

    sendDataToCarList()
    {
        window.clearTimeout(this.timer)
        this.timer = setTimeout(() => {
        //This method sends the filtered data to the carList component using a message channel.
        publish(
            this.messageContext,
            CAR_FILTERED_MESSAGE,
            {
                filters: this.filters
                
            }
        );

        /*Clearing the filters object after sending the data.
        this.filters = {...this.filters,searchKey:'',maxPrice:999999, categories:[], makeType:[]};
        console.log(this.filters);
        */
        }, 400);
        
    }
}