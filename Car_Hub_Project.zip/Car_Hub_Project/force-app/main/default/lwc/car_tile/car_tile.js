import { LightningElement, wire, track } from 'lwc';

import { MessageContext, subscribe, unsubscribe } from 'lightning/messageService';
import CAR_SELECTED from '@salesforce/messageChannel/CarSelected__c';


import CAR from '@salesforce/schema/Cars__c';
import CAR_LOGO from '@salesforce/resourceUrl/car_logo';
import CATEGORY from '@salesforce/schema/Cars__c.Category__c';
import MAKE from '@salesforce/schema/Cars__c.Make__c';
import MSRP from '@salesforce/schema/Cars__c.MSRP__c';
import CONTROL from '@salesforce/schema/Cars__c.Control__c';
import NUMBEROFSEATS from '@salesforce/schema/Cars__c.Number_of_Seats__c';
import FEUL_TYPE from '@salesforce/schema/Cars__c.Fuel_Type__c';
import PICTURE_URL from '@salesforce/schema/Cars__c.Picture_URL__c';
import CAR_NAME from '@salesforce/schema/Cars__c.Car_Name__c';
import { getFieldValue } from 'lightning/uiRecordApi';


//navigation
import { NavigationMixin } from 'lightning/navigation';
export default class Car_tile extends NavigationMixin(LightningElement) {
    car_logo = CAR_LOGO;
    car_object=CAR;
    recordId; // Reactive property

    carName;
    pictureUrl;

    category =CATEGORY;
    make =MAKE;
    msrp = MSRP;
    control = CONTROL;
    numberOfSeats = NUMBEROFSEATS;
    fuelType = FEUL_TYPE;
    
    subscription = null;

    @wire(MessageContext)
    messageContext;

   

    connectedCallback() {
        this.subscription = subscribe(
            this.messageContext,
            CAR_SELECTED,
            (message) => this.messageData(message)
        );
    }

    disconnectedCallback() {
        if (this.subscription) {
            unsubscribe(this.subscription);
            this.subscription = null;
        }
    }

    messageData(message) {
        this.recordId = message.carId; // Updates reactive property
    }
    handleRecordLoaded(event)
    {
        const{records} = event.detail;
        const recordData = records[this.recordId];
        this.carName = getFieldValue(recordData,CAR_NAME);
        this.pictureUrl = getFieldValue(recordData,PICTURE_URL);
        
    }

    get carDetails()
    {
        return this.carName? this.carName : 'Car Details'
    }
    handleNavigation()
    {
        this[NavigationMixin.Navigate]({
            type:'standard__recordPage',
            attributes:{
                recordId: this.recordId,
                objectApiName: CAR.objectApiName,
                actionName:'view'
            }
        })
    }
}
