import { api, LightningElement, wire } from 'lwc';
import MAKETYPE from '@salesforce/schema/Cars__c.Make__c'
import { getRecord } from 'lightning/uiRecordApi';
import fetchCars from '@salesforce/apex/CarController.fetchCars';
import CAR from '@salesforce/schema/Cars__c';
import { NavigationMixin } from 'lightning/navigation';
export default class SimilarCarSelections extends NavigationMixin(LightningElement) {
    @api recordId;
    carMake
    similarCars

    @wire(getRecord,{
        recordId:'$recordId',
        fields:[MAKETYPE]
    })
    wiredRecord({error,data})
    {
        if(error)
        {
            console.error('Error in fetching record',error);
            return;
        }
        if(data)
        {
            this.carMake = data.fields.Make__c.value;
        }
    }

    fetchSimilarCars()
    {
        fetchCars({recordId:this.recordId,makeType:this.carMake}).then((result) => 
        {
            this.similarCars = result;
        }).catch((error) => 
        {
            console.error('Error in fetching similar cars',error);
        })
    }

    viewHandler(event)
    {
        const record = event.target.dataset.id;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: record,
                objectApiName: CAR,
                actionName: 'view'
            }
        })
    }
}