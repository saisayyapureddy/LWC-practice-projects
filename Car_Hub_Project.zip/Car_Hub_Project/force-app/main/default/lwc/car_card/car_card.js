import { LightningElement, track, wire } from 'lwc';

import { subscribe,MessageContext,publish } from 'lightning/messageService';
import CAR_FILTERED_MESSAGE from '@salesforce/messageChannel/CarsFiltered__c';
import CAR_SELECTED from '@salesforce/messageChannel/CarSelected__c';
import getCars from '@salesforce/apex/CarController.getCars';
export default class Car_card extends LightningElement {

    cars=[];
    error
    filters = {};
    carFilterSubscription

    @wire(getCars, {filters:'$filters'})
    carsHandler({data, error}){
        if(data){
            console.log(data)
            this.cars = data
        }
        if(error){
            this.error = error
            console.error(error)
        }
    }

     /**Load context for LMS */
     @wire(MessageContext)
     messageContext

     connectedCallback(){
         this.subscribeHandler()
     }

     subscribeHandler(){
         this.carFilterSubscription = subscribe(this.messageContext, CAR_FILTERED_MESSAGE, (message)=>this.handleFilterChanges(message))
     }
     handleFilterChanges(message){
         console.log(message.filters)
         this.filters ={...message.filters}
         console.log('filters: ', this.filters);
     }
     sendData(event)
     {
        console.log('in publish metod', event.detail.car);
        publish(this.messageContext,CAR_SELECTED,{
            carId:event.detail.car
        })
     }
}