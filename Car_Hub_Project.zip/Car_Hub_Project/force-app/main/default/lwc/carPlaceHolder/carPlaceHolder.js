import { api, LightningElement } from 'lwc';
import CAR_LOGO from '@salesforce/resourceUrl/car_logo';
export default class CarPlaceHolder extends LightningElement {

    @api message;
    car_logo = CAR_LOGO;

}