import { api, LightningElement } from 'lwc';

export default class CarsLayout extends LightningElement {

    @api car
    connectedCallback()
    {
        console.log('cars data in child',this.car);
    }

    handleClick()
    {
        this.dispatchEvent(new CustomEvent('selected', { detail:{
            car: this.car.Id
        }  }));
    }
}