declare module "@salesforce/messageChannel/CarSelected__c" {
    var CarSelected: string;
    export default CarSelected;
}