declare module "@salesforce/messageChannel/CarsFiltered__c" {
    var CarsFiltered: string;
    export default CarsFiltered;
}